/* ==========================================================
   BACKEND.JS — la SEULE couche qui parle au stockage des votes.
   Les pages appellent Backend.xxx(...) et ne savent pas si derrière
   il y a le mode demo, Google Sheets ou (plus tard) Firebase.
   Pour passer à Firebase : réécrire seulement ce fichier.
   Code volontairement ES5 (vieux navigateurs, Jiophone).
   ========================================================== */
var Backend = (function () {
  var DEMO_KEY = "vote_demo_v1";
  var DAY = 86400000;

  function norm(m) { return String(m || "").replace(/\s+/g, "").toUpperCase(); }

  /* ---------- MODE DEMO (localStorage) ---------- */
  function demoLoad() {
    var s = null;
    try { s = JSON.parse(localStorage.getItem(DEMO_KEY)); } catch (e) {}
    if (!s) { s = { endAt: Date.now() + 3 * DAY, voted: {}, counts: {} }; demoSave(s); }
    return s;
  }
  function demoSave(s) { try { localStorage.setItem(DEMO_KEY, JSON.stringify(s)); } catch (e) {} }
  function demoStudent(m) {
    var n = /^E(\d{4})$/.exec(m);
    if (!n) return null;
    var k = parseInt(n[1], 10);
    return (k >= 1 && k <= 40) ? { name: "Élève " + m } : null;
  }
  function demoVotedCount(s) { var c = 0, k; for (k in s.voted) { if (s.voted.hasOwnProperty(k)) c++; } return c; }
  function demoCall(action, p, cb) {
    var s = demoLoad(), m = norm(p.matricule), now = Date.now(), open = s.endAt > now, r, st;
    if (action === "config") {
      r = { ok: true, serverNow: now, endAt: s.endAt, open: open, total: 40, voted: demoVotedCount(s) };
    } else if (action === "check") {
      st = demoStudent(m);
      r = { ok: true, status: !open ? "closed" : !st ? "unknown" : s.voted[m] ? "already" : "ok", name: st ? st.name : "" };
    } else if (action === "vote") {
      st = demoStudent(m);
      r = { ok: true, status: !open ? "closed" : !st ? "unknown" : s.voted[m] ? "already" : "recorded" };
      if (r.status === "recorded") {
        s.voted[m] = 1; s.counts[p.candidateId] = (s.counts[p.candidateId] || 0) + 1; demoSave(s);
      }
    } else if (String(action).indexOf("admin_") === 0) {
      if (p.code !== CONFIG.DEMO_ADMIN_CODE) { r = { ok: false, error: "code" }; }
      else if (action === "admin_setTimer") {
        s.endAt = now + Number(p.days) * DAY; demoSave(s); r = { ok: true, endAt: s.endAt, serverNow: now };
      } else if (action === "admin_stop") {
        s.endAt = now; demoSave(s); r = { ok: true, endAt: s.endAt, serverNow: now };
      } else if (action === "admin_resetDemo") {
        try { localStorage.removeItem(DEMO_KEY); } catch (e) {} r = { ok: true };
      } else {
        r = { ok: true, serverNow: now, endAt: s.endAt, open: open, total: 40, voted: demoVotedCount(s), counts: s.counts };
      }
    } else { r = { ok: false, error: "action" }; }
    setTimeout(function () { cb(r); }, 350);
  }

  /* ---------- MODE GOOGLE SHEETS (Apps Script) ---------- */
  function toQuery(o) {
    var a = [], k;
    for (k in o) { if (o.hasOwnProperty(k)) a.push(encodeURIComponent(k) + "=" + encodeURIComponent(o[k])); }
    return a.join("&");
  }
  function sheetsCall(action, p, cb) {
    var xhr = new XMLHttpRequest(), isPost = (action === "vote" || String(action).indexOf("admin_") === 0), body = null, url = CONFIG.SCRIPT_URL;
    p.action = action;
    if (isPost) { body = JSON.stringify(p); xhr.open("POST", url, true); xhr.setRequestHeader("Content-Type", "text/plain;charset=utf-8"); }
    else { xhr.open("GET", url + "?" + toQuery(p), true); }
    xhr.timeout = 25000;
    xhr.onreadystatechange = function () {
      if (xhr.readyState !== 4) return;
      var r = null;
      try { r = JSON.parse(xhr.responseText); } catch (e) {}
      cb(r || { ok: false, error: "network" });
    };
    xhr.send(body);
  }

  function call(action, params, cb) {
    var p = params || {};
    if (CONFIG.MODE === "sheets" && CONFIG.SCRIPT_URL) sheetsCall(action, p, cb);
    else demoCall(action, p, cb);
  }

  return {
    config: function (cb) { call("config", {}, cb); },
    check: function (matricule, cb) { call("check", { matricule: norm(matricule) }, cb); },
    vote: function (matricule, candidateId, cb) { call("vote", { matricule: norm(matricule), candidateId: candidateId }, cb); },
    adminStats: function (code, cb) { call("admin_stats", { code: code }, cb); },
    adminSetTimer: function (code, days, cb) { call("admin_setTimer", { code: code, days: days }, cb); },
    adminStop: function (code, cb) { call("admin_stop", { code: code }, cb); },
    adminResetDemo: function (code, cb) { call("admin_resetDemo", { code: code }, cb); },
    normalize: norm
  };
})();
