/* ADMIN.JS — suivi de l'élection, minuteur, export PDF (ES5). */
(function () {
  var $ = function (id) { return document.getElementById(id); };
  var code = "", timer = null;

  function msg(id, cls, title) {
    var box = $(id); Common.clear(box);
    if (!title) return;
    var d = Common.el("div", "msg " + cls); d.appendChild(Common.el("strong", "", title)); box.appendChild(d);
  }
  function render(r) {
    var p = Common.progress(r), i, c, n, pct, line, sum = 0, best = 0;
    Common.startTimer(r);
    $("a-pct").textContent = p.pct + " %"; $("a-fill").style.width = p.pct + "%"; $("a-text").textContent = p.text;
    var box = $("a-results"); Common.clear(box);
    for (i = 0; i < CONFIG.CANDIDATES.length; i++) { n = r.counts[CONFIG.CANDIDATES[i].id] || 0; sum += n; if (n > best) best = n; }
    for (i = 0; i < CONFIG.CANDIDATES.length; i++) {
      c = CONFIG.CANDIDATES[i]; n = r.counts[c.id] || 0; pct = sum ? Math.round(n * 100 / sum) : 0;
      line = Common.el("div", "resline");
      var top = Common.el("span"); top.appendChild(Common.el("b", "", c.name)); top.appendChild(Common.el("span", "", n + " voix (" + pct + " %)"));
      var meter = Common.el("div", "meter"), fill = document.createElement("i"); fill.style.width = pct + "%"; meter.appendChild(fill);
      line.appendChild(top); line.appendChild(meter); box.appendChild(line);
    }
    $("a-total").textContent = "Total des voix : " + sum + " · Non votants : " + (r.total - r.voted);
    $("pr-title").textContent = CONFIG.TITLE + " — " + CONFIG.SCHOOL;
    $("pr-date").textContent = "Rapport du " + new Date().toLocaleString("fr-FR") + (Common.isOpen() ? " (vote en cours)" : " (vote clôturé)");
  }
  function load() {
    Backend.adminStats(code, function (r) {
      if (!r || !r.ok) { if (r && r.error === "code") { logout("Code incorrect."); } return; }
      render(r);
    });
  }
  function logout(text) { code = ""; $("panel").hidden = true; $("login").hidden = false; msg("login-msg", "err", text); if (timer) { clearInterval(timer); timer = null; } }

  $("btn-login").onclick = function () {
    var btn = $("btn-login"); code = $("code").value; msg("login-msg", "", "");
    if (!code) { msg("login-msg", "err", "Entre le code."); return; }
    btn.disabled = true;
    Backend.adminStats(code, function (r) {
      btn.disabled = false;
      if (!r) { msg("login-msg", "err", "Pas de connexion."); return; }
      if (!r.ok) { code = ""; msg("login-msg", "err", "Code incorrect."); return; }
      $("login").hidden = true; $("panel").hidden = false; render(r);
      timer = setInterval(load, 15000);
    });
  };
  $("code").onkeydown = function (e) { if ((e.keyCode || e.which) === 13) $("btn-login").onclick(); };

  $("btn-start").onclick = function () {
    var d = $("days").value;
    if (!window.confirm("Démarrer le vote pour " + d + " jour(s) à partir de maintenant ?")) return;
    Backend.adminSetTimer(code, d, function (r) { if (r && r.ok) { msg("timer-msg", "ok", "Minuteur lancé."); load(); } else { msg("timer-msg", "err", "Échec. Réessaie."); } });
  };
  $("btn-stop").onclick = function () {
    if (!window.confirm("Clôturer le vote maintenant ? Plus personne ne pourra voter.")) return;
    Backend.adminStop(code, function (r) { if (r && r.ok) { msg("timer-msg", "ok", "Vote clôturé."); load(); } else { msg("timer-msg", "err", "Échec. Réessaie."); } });
  };
  $("btn-pdf").onclick = function () { window.print(); };
  $("btn-reload").onclick = load;
  $("school").textContent = CONFIG.SCHOOL;
  Backend.config(function (cfg) { if (cfg && cfg.ok) Common.startTimer(cfg); });
})();
