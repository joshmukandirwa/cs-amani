/* VOTE.JS — parcours de vote (ES5). */
(function () {
  var $ = function (id) { return document.getElementById(id); };
  var state = { matricule: "", name: "", candidate: null, cfg: null };
  var STEPS = ["id", "choice", "recap", "final", "done", "already", "closed"];

  function show(name) {
    var i;
    for (i = 0; i < STEPS.length; i++) { $("step-" + STEPS[i]).hidden = (STEPS[i] !== name); }
    window.scrollTo(0, 0);
  }
  function msg(id, cls, title, text) {
    var box = $(id); Common.clear(box);
    if (!title) return;
    var d = Common.el("div", "msg " + cls);
    d.appendChild(Common.el("strong", "", title));
    if (text) d.appendChild(document.createTextNode(text));
    box.appendChild(d);
  }
  function findCandidate(id) {
    var i; for (i = 0; i < CONFIG.CANDIDATES.length; i++) { if (CONFIG.CANDIDATES[i].id === id) return CONFIG.CANDIDATES[i]; }
    return null;
  }

  /* ---------- Config + minuteur + participation ---------- */
  function refresh(cb) {
    Backend.config(function (cfg) {
      if (!cfg || !cfg.ok) { if (cb) cb(false); return; }
      state.cfg = cfg;
      Common.startTimer(cfg);
      var p = Common.progress(cfg);
      $("pp-fill").style.width = p.pct + "%"; $("pp-text").textContent = p.text;
      $("dp-fill").style.width = p.pct + "%"; $("dp-text").textContent = p.text;
      if (cb) cb(true);
    });
  }
  function closedMessage() {
    if (!state.cfg || !state.cfg.endAt) return "Le vote n’a pas encore commencé. Reviens plus tard.";
    return "Le vote est terminé. Merci de ta participation.";
  }

  /* ---------- Étape 1 : matricule ---------- */
  $("btn-check").onclick = function () {
    var m = Backend.normalize($("matricule").value), btn = $("btn-check");
    msg("id-msg", "", "");
    if (!m) { msg("id-msg", "err", "Entre ton matricule."); return; }
    if (!Common.isOpen()) { show("closed"); $("closed-msg").textContent = closedMessage(); return; }
    btn.disabled = true; btn.textContent = "Vérification…";
    Backend.check(m, function (r) {
      btn.disabled = false; btn.textContent = "Vérifier mon matricule";
      if (!r || !r.ok) { msg("id-msg", "err", "Pas de connexion.", "Vérifie ton réseau et réessaie."); return; }
      if (r.status === "unknown") { msg("id-msg", "err", "Matricule introuvable.", "Vérifie le numéro écrit sur ta carte d’élève."); return; }
      if (r.status === "already") { show("already"); return; }
      if (r.status === "closed") { show("closed"); $("closed-msg").textContent = closedMessage(); return; }
      state.matricule = m; state.name = r.name || "";
      $("who").textContent = "Matricule " + m + (state.name ? " · " + state.name : "");
      state.candidate = null; renderBallot(); show("choice");
    });
  };
  $("matricule").onkeydown = function (e) { if ((e.keyCode || e.which) === 13) $("btn-check").onclick(); };

  /* ---------- Étape 2 : bulletin ---------- */
  function renderBallot() {
    var ul = $("ballot"), i; Common.clear(ul); msg("choice-msg", "", "");
    for (i = 0; i < CONFIG.CANDIDATES.length; i++) { ul.appendChild(ballotItem(CONFIG.CANDIDATES[i])); }
  }
  function ballotItem(c) {
    var li = document.createElement("li"), lab = Common.el("label", "cand"), inp = document.createElement("input"), row = Common.el("div", "row"), img = document.createElement("img"), info = Common.el("div", "info");
    inp.type = "radio"; inp.name = "cand"; inp.value = c.id;
    img.className = "photo"; img.src = c.photo; img.alt = "Photo de " + c.name; img.width = 76; img.height = 76;
    info.appendChild(Common.el("strong", "", c.name)); info.appendChild(Common.el("span", "slogan", c.slogan));
    row.appendChild(img); row.appendChild(info); row.appendChild(Common.el("span", "tick"));
    lab.appendChild(inp); lab.appendChild(row);
    inp.onchange = function () {
      var all = document.querySelectorAll(".cand"), k;
      for (k = 0; k < all.length; k++) all[k].className = "cand";
      lab.className = "cand on"; state.candidate = c.id; msg("choice-msg", "", "");
    };
    li.appendChild(lab);
    var more = document.createElement("details"), sum = Common.el("summary", "", "Voir le programme"), ul = document.createElement("ul"), j;
    more.className = "more"; more.appendChild(sum);
    more.appendChild(Common.el("p", "", c.bio));
    for (j = 0; j < c.points.length; j++) ul.appendChild(Common.el("li", "", c.points[j]));
    more.appendChild(ul); li.appendChild(more);
    return li;
  }
  $("btn-submit").onclick = function () {
    if (!state.candidate) { msg("choice-msg", "err", "Choisis un candidat.", "Touche une ligne pour le sélectionner."); return; }
    var c = findCandidate(state.candidate), box = $("recap"), img = document.createElement("img");
    Common.clear(box);
    img.className = "photo"; img.src = c.photo; img.alt = c.name; img.width = 120; img.height = 120;
    box.appendChild(img); box.appendChild(Common.el("h3", "", c.name)); box.appendChild(Common.el("p", "slogan", c.slogan));
    show("recap");
  };
  $("btn-notme").onclick = function () { state.matricule = ""; state.candidate = null; $("matricule").value = ""; show("id"); };

  /* ---------- Étapes 3 et 4 ---------- */
  $("btn-recap-back").onclick = function () { show("choice"); };
  $("btn-recap-ok").onclick = function () { $("final-name").textContent = findCandidate(state.candidate).name; msg("final-msg", "", ""); show("final"); };
  $("btn-final-cancel").onclick = function () { show("choice"); };
  $("btn-final-ok").onclick = function () {
    var btn = $("btn-final-ok"), cancel = $("btn-final-cancel");
    btn.disabled = true; cancel.disabled = true; btn.textContent = "Envoi en cours…"; msg("final-msg", "", "");
    Backend.vote(state.matricule, state.candidate, function (r) {
      btn.disabled = false; cancel.disabled = false; btn.textContent = "Oui, valider mon vote";
      if (!r || !r.ok) { msg("final-msg", "err", "Pas de connexion.", "Ton vote n’est pas encore enregistré. Réessaie."); return; }
      if (r.status === "recorded") { state.candidate = null; refresh(function () { show("done"); }); return; }
      if (r.status === "already") { show("already"); return; }
      if (r.status === "closed") { show("closed"); $("closed-msg").textContent = closedMessage(); return; }
      msg("final-msg", "err", "Erreur.", "Recommence depuis le début.");
    });
  };
  $("btn-already-back").onclick = function () { $("matricule").value = ""; show("id"); };
  $("btn-refresh").onclick = function () { refresh(); };

  /* ---------- Démarrage ---------- */
  $("school").textContent = CONFIG.SCHOOL; $("title").textContent = CONFIG.TITLE;
  refresh(function (ok) {
    if (!ok) { $("bar-label").textContent = "Connexion impossible"; return; }
    if (!Common.isOpen()) { show("closed"); $("closed-msg").textContent = closedMessage(); }
  });
  setInterval(function () { refresh(); }, 30000);
})();
