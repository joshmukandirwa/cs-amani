/**
 * VOTE EN LIGNE — Google Apps Script
 * 1) Ouvre ton Google Sheet > Extensions > Apps Script, colle ce fichier.
 * 2) Change ADMIN_CODE ci-dessous.
 * 3) Déployer > Nouveau déploiement > Application Web
 *    Exécuter en tant que : Moi · Accès : Tout le monde.
 * 4) Copie l'URL « /exec » dans js/config.js (SCRIPT_URL) et mets MODE: "sheets".
 *
 * Feuilles utilisées (créées automatiquement sauf la liste des élèves) :
 *  - "Élèves 2026-2027" : A Matricule, B Nom, C Postnom, D Prénom (ligne 1 = titres)
 *  - "Émargement"       : QUI a voté (matricule + heure), sans le choix
 *  - "Urne"             : le CHOIX de chaque vote (candidat + heure), sans matricule
 *    -> vote secret : aucune ligne ne relie un élève à son candidat.
 *  - "Config"           : B1 = heure de fin du vote (gérée par la page admin)
 */
var ADMIN_CODE = "CHANGE-MOI";
var SH_STUDENTS = "Élèves 2026-2027", SH_SIGN = "Émargement", SH_URN = "Urne", SH_CONF = "Config";
var CANDIDATE_IDS = ["c1", "c2", "c3"]; // mêmes id que dans js/config.js

function sheet_(n) { var ss = SpreadsheetApp.getActiveSpreadsheet(); return ss.getSheetByName(n) || ss.insertSheet(n); }
function json_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }
function norm_(m) { return String(m || "").replace(/\s+/g, "").toUpperCase(); }
function endAt_() { var v = sheet_(SH_CONF).getRange("B1").getValue(); return v ? Number(v) : 0; }
function isOpen_() { var e = endAt_(); return e > 0 && Date.now() < e; }
function total_() { return Math.max(0, sheet_(SH_STUDENTS).getLastRow() - 1); }
function voted_() { return sheet_(SH_SIGN).getLastRow(); }

function findStudent_(m) {
  var s = sheet_(SH_STUDENTS), last = s.getLastRow();
  if (last < 2) return null;
  var v = s.getRange(2, 1, last - 1, 4).getValues();
  for (var i = 0; i < v.length; i++) { if (norm_(v[i][0]) === m) return { name: (v[i][3] + " " + v[i][1]).replace(/^\s+|\s+$/g, "") }; }
  return null;
}
function hasVoted_(m) {
  var s = sheet_(SH_SIGN), last = s.getLastRow();
  if (last < 1) return false;
  var v = s.getRange(1, 1, last, 1).getValues();
  for (var i = 0; i < v.length; i++) { if (norm_(v[i][0]) === m) return true; }
  return false;
}
function counts_() {
  var s = sheet_(SH_URN), last = s.getLastRow(), out = {}, i;
  for (i = 0; i < CANDIDATE_IDS.length; i++) out[CANDIDATE_IDS[i]] = 0;
  if (last < 1) return out;
  var v = s.getRange(1, 1, last, 1).getValues();
  for (i = 0; i < v.length; i++) { if (out.hasOwnProperty(v[i][0])) out[v[i][0]]++; }
  return out;
}
function base_() { return { ok: true, serverNow: Date.now(), endAt: endAt_(), open: isOpen_(), total: total_(), voted: voted_() }; }

function doGet(e) {
  var a = e.parameter.action;
  if (a === "config") return json_(base_());
  if (a === "check") {
    var m = norm_(e.parameter.matricule), st = findStudent_(m);
    var status = !isOpen_() ? "closed" : !st ? "unknown" : hasVoted_(m) ? "already" : "ok";
    return json_({ ok: true, status: status, name: st ? st.name : "" });
  }
  return json_({ ok: false, error: "action" });
}

function doPost(e) {
  var p; try { p = JSON.parse(e.postData.contents); } catch (x) { return json_({ ok: false, error: "json" }); }
  if (p.action === "vote") {
    var lock = LockService.getScriptLock(); lock.waitLock(20000);
    try {
      var m = norm_(p.matricule), st = findStudent_(m);
      if (!isOpen_()) return json_({ ok: true, status: "closed" });
      if (!st) return json_({ ok: true, status: "unknown" });
      if (CANDIDATE_IDS.indexOf(p.candidateId) < 0) return json_({ ok: false, error: "candidate" });
      if (hasVoted_(m)) return json_({ ok: true, status: "already" });
      sheet_(SH_SIGN).appendRow([m, new Date()]);
      sheet_(SH_URN).appendRow([p.candidateId, new Date()]);
      return json_({ ok: true, status: "recorded" });
    } finally { lock.releaseLock(); }
  }
  if (String(p.action).indexOf("admin_") === 0) {
    if (p.code !== ADMIN_CODE) return json_({ ok: false, error: "code" });
    if (p.action === "admin_setTimer") {
      var days = Math.min(3, Math.max(1, Number(p.days) || 1));
      sheet_(SH_CONF).getRange("A1:B1").setValues([["endAt", Date.now() + days * 86400000]]);
    } else if (p.action === "admin_stop") {
      sheet_(SH_CONF).getRange("A1:B1").setValues([["endAt", Date.now()]]);
    }
    var r = base_(); r.counts = counts_(); return json_(r);
  }
  return json_({ ok: false, error: "action" });
}
